<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Ejercicio4</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
 
</head>
<body>
    <form action="Ejercicio4.php" method="post">
<div>   
    <h2>Agente Virtual PHP</h2>    
    <h1>Contactos:</h1>
        <div>
            Para guardar presione el boton
            Nombre:<input type="text" name="nombre"><br>
            Trabajo:<input type="text" name="trabajo"><br>
            Telefono:<input type="text" name="telefono"><br>
            Direccion:<input type="text" name="direccion"><br>
            Otras:<input type="text" name="otras"><br>
            <input value="Guardar!" type="submit" name="guardar" id="boton1">
            <input value="Reset" type="reset" name="reset" id="boton1">
        </div>
    </form>

    <?php
    if(isset($_REQUEST['guardar'])){
        $nombre=$_REQUEST['nombre'];
        $trabajo=$_REQUEST['trabajo'];
        $telefono=$_REQUEST['telefono'];
        $direccion=$_REQUEST['direccion'];
        $otras=$_REQUEST['otras'];
    }
    
    
    if($datos=="Por Pantalla"){
        print "El alumno $nombre, con telefono $telefono, $matriculado en $ciclo\n";
    }
    else if($datos=="En Archivo datos.txt"){
        $file = fopen("datos.txt", "r");
        while(!feof($file)) {
            $linea = fgets($file);
            if(!empty($linea)) {
            $arrayDatos = explode("El alumno", $linea,);
                echo $arrayDatos[0];
                echo $arrayDatos[1];
                echo $arrayDatos[2];
            }
        }
        fclose($file);
    }

?>

</body>
    </html>

