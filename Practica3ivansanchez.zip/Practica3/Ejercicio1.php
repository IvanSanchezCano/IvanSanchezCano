<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Ejercicio1</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
 
</head>
<body>
    <form action="Ejercicio1.php" method="post">
        <p>Escribe el alto y ancho (0 < numeros <= 100) y mostrare un rectangulo de estrellas de ese tamaño.</p>
        Ancho:<input type="text" name="ancho" id="form1"><br>
        Alto:<input type="text" name="alto" id="form1"><br>
        <input value="Dibujar" type="submit" name="dibujar" id="boton1">
        <input value="Borrar" type="reset" name="borrar" id="boton2">
    </form>

    <?php



if(isset($_REQUEST["dibujar"])) {
    $ancho=$_REQUEST['ancho'];
    $alto=$_REQUEST['alto'];
for ($i=1;$i<=$ancho;$i++){
    for ($j=1;$j<=$alto;$j++){
        print "* ";
    }
    print "<BR>\n ";
}
}
?> 
</body>
</html>



