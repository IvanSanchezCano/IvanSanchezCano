<?php
    if(isset($_REQUEST['enviar'])){
        $nombre=$_REQUEST['nombre'];
        $telefono=$_REQUEST['telefono'];
        $matriculado=$_REQUEST['matriculado'];
        $datos=$_REQUEST['sele'];
        $secu=$_REQUEST['secu'];
        $bach=$_REQUEST['bach'];
        $medio=$_REQUEST['medio'];
        $sup=$_REQUEST['sup'];
        
    }
    if($matriculado=="on"){
        $matriculado="está matriculado";
    }
    else{ 
        $matriculado="no esta matriculado";
    }
    if($secu=="on"){
        $ciclo="Secundaria";
    }
    if($bach=="on"){
        $ciclo="un Bachillerato";
    }
    if($medio=="on"){
        $ciclo="un Ciclo Medio";
    }
    if($sup=="on"){
        $ciclo="un Ciclo Superior";
    }
    
    if($datos=="Por Pantalla"){
        $datosdatos="El alumno $nombre, con telefono $telefono, $matriculado en $ciclo\n";
        print $datosdatos;
    }
    else if($datos=="En Archivo datos.txt"){
        $nombrearchivo="datos.txt";
        $archivo=fopen($nombrearchivo, "w");
        fwrite($archivo, $datosdatos);
        fclose($archivo);
        echo "<a href=./mostrardatos.php>Mostrar archivo</a>";
    }

?>


