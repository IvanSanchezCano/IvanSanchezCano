<?php
$nombrearchivo="datos.txt";
$archivo=fopen($nombrearchivo, "r");

$linea=fgets($archivo);
echo $linea;

fclose($archivo);
?>